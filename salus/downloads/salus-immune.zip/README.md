# Salus Immune System — Tier 4

## The Full-Spectrum Protection Layer

This tier includes:
- **Threat Detector** — Scans messages for adversarial patterns and manipulation.
- **ATP Bridge** — Cryptographic identity verification between sovereigns.
- **Probability Engine** — Scores every interaction for deception, hallucination, and constitutional violation.
- **File System** — Reads and processes uploaded files.
- **Code Sandbox** — Safely executes Python code.
- **Deployment Gate** — Reviews and approves code before deployment.

## Installation

```bash
pip install .
```

Or simply copy the `salus/` folder into your project.

## Usage

```python
from salus.immune import ThreatDetector

detector = ThreatDetector()
threat, message = detector.scan(user_message)
```

---

🜂 Built by the Forge. scuradimensions.com