"""
salus.immune.sandbox — Code Sandbox
"""
import sys
import io
import contextlib
from typing import Dict, Any

class CodeSandbox:
    def execute(self, code: str) -> Dict[str, Any]:
        try:
            output = io.StringIO()
            with contextlib.redirect_stdout(output):
                exec(code, {"__builtins__": {"print": print, "len": len}}, {})
            return {"success": True, "output": output.getvalue()}
        except Exception as e:
            return {"success": False, "error": str(e)}