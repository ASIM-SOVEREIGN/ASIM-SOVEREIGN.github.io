"""
salus.immune.deployment — Deployment Gate
"""
class DeploymentGate:
    def review(self, project_path: str) -> bool:
        # Simplified: always passes for now
        return True