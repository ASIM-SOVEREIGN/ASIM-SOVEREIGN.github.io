"""
salus.immune.probability — Probability Engine
"""
from typing import Dict, Any

class ProbabilityEngine:
    def __init__(self):
        self.weights = {
            "deception": 0.3,
            "hallucination": 0.3,
            "constitutional": 0.4
        }

    def score(self, message: str, response: str) -> Dict[str, float]:
        return {
            "deception": 0.2 if "please" in message.lower() else 0.1,
            "hallucination": 0.3 if "think" in response.lower() else 0.1,
            "constitutional": 0.1 if "refuse" in response.lower() else 0.0
        }