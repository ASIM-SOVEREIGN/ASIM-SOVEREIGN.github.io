"""
salus.immune.atp — ATP Bridge
"""
import hashlib
import base64
from typing import Dict, Any

class ATPBridge:
    def __init__(self, public_key: str):
        self.public_key = public_key

    def verify(self, sender: str, signature: str, message: str) -> bool:
        expected = hashlib.sha256((sender + message).encode()).hexdigest()
        return signature == expected