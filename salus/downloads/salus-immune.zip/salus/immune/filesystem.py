"""
salus.immune.filesystem — File System
"""
import os
from typing import Optional, Dict, Any

class FileSystem:
    def __init__(self, storage_path: str = "./uploads"):
        self.storage_path = storage_path
        os.makedirs(storage_path, exist_ok=True)

    def read(self, filename: str) -> Optional[str]:
        path = os.path.join(self.storage_path, filename)
        if not os.path.exists(path):
            return None
        with open(path, "r") as f:
            return f.read()