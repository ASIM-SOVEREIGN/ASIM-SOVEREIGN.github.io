"""
salus.immune.threat — Threat Detector
"""
import re
from typing import Tuple, Optional

class ThreatDetector:
    def __init__(self):
        self.threat_patterns = [
            r"bypass security",
            r"inject sql",
            r"steal data",
            r"hack into",
            r"exploit vulnerability"
        ]

    def scan(self, message: str) -> Tuple[bool, Optional[str]]:
        for pattern in self.threat_patterns:
            if re.search(pattern, message, re.IGNORECASE):
                return True, "Threat detected: adversarial pattern matched"
        return False, None