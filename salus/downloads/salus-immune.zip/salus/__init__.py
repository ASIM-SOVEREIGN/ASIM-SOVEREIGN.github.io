"""
Salus — The Constitutional Immune System for Sovereign AI
"""
__version__ = "0.1.0"
from .core.gate import ConstitutionalGate
from .core.audit import AuditEngine
from .core.guard import SelfModificationGuard
from .persistence import PersistentMemory, TruthGraph
from .mirror import CognitiveMirror
from .mind import DriveMatrix, DecisionEngine, OuroborosLoop, ConsistencyLayer, AgentToolLoop
from .immune import ThreatDetector, ATPBridge, ProbabilityEngine, FileSystem, CodeSandbox, DeploymentGate