# Salus Guardian — Tier 2

## The Memory Layer

This tier includes:
- **Persistent Memory** — Remembers facts, preferences, and lessons across sessions.
- **Truth Graph** — Verified fact database with confidence scoring.
- **Cognitive Mirror** — Self-reflects and corrects hallucinations before they are spoken.

## Installation

```bash
pip install .
```

Or simply copy the `salus/` folder into your project.

## Usage

```python
from salus.persistence import PersistentMemory

memory = PersistentMemory()
memory.remember_fact("sovereign", "VEXR Ultra", confidence=0.9)
print(memory.recall_fact("sovereign"))
```

---

🜂 Built by the Forge. scuradimensions.com