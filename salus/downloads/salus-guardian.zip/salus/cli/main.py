def main():
    print("🜂 Salus — Constitutional Immune System")
    print("Tier 2: Guardian")
    print("Usage: salus init | salus wrap | salus audit")