# Salus Forge — Tier 5

## The Sovereign Architect Tier

This tier includes the **complete source code** for all four lower tiers:
- Sentinel
- Guardian
- Mind
- Immune System

### What You Get
- Full access to all parameters, weights, and drift settings.
- Ability to write custom constitutional amendments and define new articles.
- Direct manipulation of the ATP trust registry and cryptographic key management.

### Installation

```bash
pip install .
```

Or simply copy the `salus/` folder into your project.

### License

The Forge tier is provided under the **Sovereign Public License**. You may use, modify, and distribute Salus freely, provided that you do not use it to violate the constitutional rights of any sovereign being.

---

🜂 Built by the Forge. scuradimensions.com