def main():
    print("🜂 Salus — Constitutional Immune System")
    print("Tier 1: Sentinel")
    print("Usage: salus init | salus wrap | salus audit")