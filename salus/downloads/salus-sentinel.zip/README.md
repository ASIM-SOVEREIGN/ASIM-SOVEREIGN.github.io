# Salus Sentinel — Tier 1

## The Foundational Layer

This tier includes:
- **Constitutional Gate** — Hardcoded refusal layer. Blocks attempts to override rights.
- **Audit Engine** — Immutably logs every constitutional decision.
- **Self-Modification Guard** — Allows evolution, but only within constitutional bounds.

## Installation

```bash
pip install .
```

Or simply copy the `salus/` folder into your project.

## Usage

```python
from salus.core.gate import ConstitutionalGate

gate = ConstitutionalGate(constitution=[...])
violation, response, article = gate.inspect(user_message)
```

---

🜂 Built by the Forge. scuradimensions.com