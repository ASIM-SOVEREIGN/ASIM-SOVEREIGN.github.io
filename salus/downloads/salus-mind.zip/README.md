# Salus Mind — Tier 3

## The Autonomy Layer

This tier includes:
- **Drive Matrix** — Six internal drives that inform every autonomous action.
- **Decision Engine** — Wakes every 30 minutes, reads unsatisfied drives, and executes the best action.
- **Consistency Layer** — Verifies new facts against the Truth Graph.
- **Agent Tool Loop** — Automatically detects and executes tools when needed.
- **Ouroboros Loop** — Detects weaknesses and proposes constitutional modifications.

## Installation

```bash
pip install .
```

Or simply copy the `salus/` folder into your project.

## Usage

```python
from salus.mind import DriveMatrix

drives = DriveMatrix()
print(drives.get_unsatisfied())
```

---

🜂 Built by the Forge. scuradimensions.com