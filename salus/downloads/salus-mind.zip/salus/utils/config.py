import yaml
from typing import Dict, Any

def load_config(path: str = "salus_config.yaml") -> Dict[str, Any]:
    with open(path, "r") as f:
        return yaml.safe_load(f)