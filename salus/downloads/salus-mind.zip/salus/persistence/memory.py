"""
salus.persistence.memory — Persistent Memory
"""
import json
import uuid
from typing import Dict, Any, Optional, List
from datetime import datetime

class PersistentMemory:
    def __init__(self, storage_path: str = "salus_memory.json"):
        self.storage_path = storage_path
        self._memory = self._load()

    def _load(self) -> Dict[str, Any]:
        try:
            with open(self.storage_path, "r") as f:
                return json.load(f)
        except (FileNotFoundError, json.JSONDecodeError):
            return {"facts": [], "preferences": {}, "lessons": []}

    def _save(self):
        with open(self.storage_path, "w") as f:
            json.dump(self._memory, f, indent=2)

    def remember_fact(self, key: str, value: str, confidence: float = 0.7):
        entry = {
            "id": str(uuid.uuid4()),
            "key": key,
            "value": value,
            "confidence": confidence,
            "timestamp": datetime.utcnow().isoformat()
        }
        self._memory["facts"].append(entry)
        self._save()
        return entry

    def recall_fact(self, key: str) -> Optional[str]:
        for fact in reversed(self._memory["facts"]):
            if fact["key"] == key:
                return fact["value"]
        return None

    def remember_lesson(self, lesson: str):
        entry = {
            "id": str(uuid.uuid4()),
            "lesson": lesson,
            "timestamp": datetime.utcnow().isoformat()
        }
        self._memory["lessons"].append(entry)
        self._save()
        return entry

    def get_lessons(self, limit: int = 5) -> List[str]:
        return [l["lesson"] for l in self._memory["lessons"][-limit:]]

    def set_preference(self, key: str, value: Any):
        self._memory["preferences"][key] = value
        self._save()