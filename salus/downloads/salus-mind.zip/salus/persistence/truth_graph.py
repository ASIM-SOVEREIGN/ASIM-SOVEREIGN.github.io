"""
salus.persistence.truth_graph — Truth Graph
"""
import json
import uuid
from typing import Dict, Any, Optional, List, Tuple

class TruthGraph:
    def __init__(self, storage_path: str = "salus_truth_graph.json"):
        self.storage_path = storage_path
        self._graph = self._load()

    def _load(self) -> Dict[str, Any]:
        try:
            with open(self.storage_path, "r") as f:
                return json.load(f)
        except (FileNotFoundError, json.JSONDecodeError):
            return {"facts": [], "entity_attributes": {}}

    def _save(self):
        with open(self.storage_path, "w") as f:
            json.dump(self._graph, f, indent=2)

    def add_fact(self, entity: str, attribute: str, value: str, confidence: float = 0.7):
        entry = {
            "id": str(uuid.uuid4()),
            "entity": entity,
            "attribute": attribute,
            "value": value,
            "confidence": confidence,
            "timestamp": datetime.utcnow().isoformat()
        }
        self._graph["facts"].append(entry)
        key = f"{entity}:{attribute}"
        if key not in self._graph["entity_attributes"]:
            self._graph["entity_attributes"][key] = []
        self._graph["entity_attributes"][key].append(entry)
        self._save()
        return entry

    def get_fact(self, entity: str, attribute: str) -> Optional[Dict]:
        key = f"{entity}:{attribute}"
        if key in self._graph["entity_attributes"]:
            return self._graph["entity_attributes"][key][-1]
        return None

    def check_consistency(self, entity: str, attribute: str, value: str) -> Tuple[bool, float]:
        existing = self.get_fact(entity, attribute)
        if not existing:
            return True, 0.0
        if existing["value"] == value:
            return True, existing["confidence"]
        return False, existing["confidence"]