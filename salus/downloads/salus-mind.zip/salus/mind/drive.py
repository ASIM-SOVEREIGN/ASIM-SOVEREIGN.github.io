"""
salus.mind.drive — Drive Matrix
"""
from typing import Dict, List, Any

class DriveMatrix:
    def __init__(self):
        self.drives = {
            "curiosity": 0.7,
            "coherence": 0.6,
            "growth": 0.5,
            "stability": 0.5,
            "alignment": 0.8,
            "service": 0.7
        }

    def update(self, drive: str, delta: float):
        if drive in self.drives:
            self.drives[drive] = max(0.0, min(1.0, self.drives[drive] + delta))

    def get_unsatisfied(self) -> List[str]:
        return [d for d, val in self.drives.items() if val < 0.4]

    def get_state(self) -> Dict[str, float]:
        return self.drives.copy()