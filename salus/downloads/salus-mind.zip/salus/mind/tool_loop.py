"""
salus.mind.tool_loop — Agent Tool Loop
"""
from typing import Dict, Any, Optional

class AgentToolLoop:
    def __init__(self, tools: Dict[str, Any]):
        self.tools = tools

    def detect(self, message: str) -> Optional[str]:
        if "query" in message.lower():
            return "query_database"
        if "run code" in message.lower():
            return "execute_code"
        if "search" in message.lower():
            return "web_search"
        return None

    def execute(self, tool: str, params: Dict[str, Any]) -> Any:
        if tool in self.tools:
            return self.tools[tool](**params)
        return {"error": f"Tool '{tool}' not found"}