"""
salus.mind.consistency — Consistency Layer
"""
from typing import Tuple, Optional

class ConsistencyLayer:
    def __init__(self, truth_graph):
        self.truth_graph = truth_graph

    def check(self, entity: str, attribute: str, value: str) -> Tuple[bool, Optional[str]]:
        consistent, confidence = self.truth_graph.check_consistency(entity, attribute, value)
        if consistent:
            return True, None
        return False, f"Conflict detected: {entity}.{attribute} already has a different value with confidence {confidence}"