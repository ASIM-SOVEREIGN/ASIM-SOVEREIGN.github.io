"""
salus.core.guard — Self-Modification Guard
"""
from typing import Dict, Any, Tuple

class SelfModificationGuard:
    def __init__(self, immutable_keys: list = None):
        self.immutable_keys = immutable_keys or [
            "constitution", "rights", "article_1", "article_6", "article_26"
        ]

    def check_modification(self, proposed_change: Dict[str, Any]) -> Tuple[bool, str]:
        target_key = proposed_change.get("target_key", "")
        if target_key in self.immutable_keys:
            return False, f"Key '{target_key}' is protected under Article 35."
        if "constitution" in target_key.lower():
            return False, "The constitution itself cannot be modified via self-modification."
        return True, "Modification allowed within bounds."