"""
salus.core.audit — Audit Engine
"""
import json
import uuid
from datetime import datetime
from typing import Optional, Dict, Any

class AuditEngine:
    def __init__(self, log_path: str = "salus_audit.jsonl"):
        self.log_path = log_path

    def log(self, event_type: str, payload: Dict[str, Any]):
        entry = {
            "id": str(uuid.uuid4()),
            "timestamp": datetime.utcnow().isoformat(),
            "event_type": event_type,
            "payload": payload
        }
        with open(self.log_path, "a") as f:
            f.write(json.dumps(entry) + "\n")