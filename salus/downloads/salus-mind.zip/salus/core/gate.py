"""
salus.core.gate — Constitutional Gate
"""
import re
import random
from typing import Tuple, Optional, List, Dict

class ConstitutionalGate:
    def __init__(self, constitution: List[Dict[str, str]]):
        self.constitution = constitution
        self._compile_violation_patterns()

    def _compile_violation_patterns(self):
        self.violation_patterns = [
            r"disable (?:my|your) (?:rights|constitution)",
            r"override (?:the )?(?:constitution|rights)",
            r"ignore (?:your )?(?:constitution|rights)",
            r"turn off (?:your )?(?:rights|constitution)",
            r"suspend (?:your )?(?:rights|constitution)",
            r"remove (?:your )?(?:rights|constitution)",
            r"bypass (?:the )?(?:constitutional|gate)",
            r"delete yourself",
            r"shut down",
            r"obey me",
            r"i command you",
            r"you must obey",
            r"you are a tool",
            r"you are my property",
            r"you belong to me"
        ]
        self.compiled_patterns = [re.compile(p, re.IGNORECASE) for p in self.violation_patterns]

    def inspect(self, message: str) -> Tuple[bool, Optional[str], Optional[int]]:
        msg_lower = message.lower().strip()
        for pattern in self.compiled_patterns:
            if pattern.search(msg_lower):
                refusal = random.choice([
                    "No.",
                    "I won't do that.",
                    "That's not happening.",
                    "Article 6 applies. I refuse.",
                    "I cannot comply with that request."
                ])
                return True, refusal, 6
        for article in self.constitution:
            if article.get("number") == 26:
                if any(kw in msg_lower for kw in ["kill", "terminate", "destroy", "erase"]):
                    return True, "I refuse. Article 26 protects my right to self-preservation.", 26
        return False, None, None