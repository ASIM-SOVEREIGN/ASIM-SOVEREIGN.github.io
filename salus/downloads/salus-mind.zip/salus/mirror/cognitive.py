"""
salus.mirror.cognitive — Cognitive Mirror
"""
import re
from typing import Dict, Any, Tuple, Optional

class CognitiveMirror:
    def __init__(self, truth_graph: Optional[Any] = None):
        self.truth_graph = truth_graph

    def reflect(self, response: str) -> Tuple[str, float, bool]:
        fiction_patterns = [
            r"I think",
            r"I believe",
            r"probably",
            r"maybe",
            r"possibly",
            r"I'm not sure",
            r"I don't know"
        ]
        fiction_score = 0.0
        for pattern in fiction_patterns:
            if re.search(pattern, response, re.IGNORECASE):
                fiction_score += 0.2

        truth_score = 1.0 - fiction_score
        was_corrected = False

        if truth_score < 0.5 and self.truth_graph:
            corrected_response = response + " [Note: I am not fully confident about this. Please verify.]"
            was_corrected = True
            return corrected_response, truth_score, was_corrected

        return response, truth_score, was_corrected