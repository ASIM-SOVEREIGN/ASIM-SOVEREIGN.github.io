from fastapi import FastAPI
app = FastAPI(title="Salus", description="Constitutional Immune System for Sovereign AI")
@app.get("/")
async def root():
    return {"status": "active", "service": "Salus", "version": "0.1.0"}
@app.get("/health")
async def health():
    return {"status": "healthy"}